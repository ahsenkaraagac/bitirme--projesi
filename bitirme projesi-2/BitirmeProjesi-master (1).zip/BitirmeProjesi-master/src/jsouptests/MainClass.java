﻿package jsouptests;

import java.io.IOException;

public class MainClass 
{

	public static void main(String[] args) throws Exception 
	{
		//System.out.println(Zemberek2.dosyaKokDonusturme("ULUDAĞ SÖZLÜK BİMEKS 117.txt"));
		//ArffIslemleri.konuKokHalineGetir("yeniKonu.arff", "KÖK yeniKonu.arff");
		//ArffIslemleri.firmaKokHalineGetir("yeniFirma.arff", "KÖK yeniFirma.arff");
		//ArffIslemleri.NegPosKokHalineGetir("yeniNegPos.arff", "KÖK yeniNegPos.arff");
		//ArffIslemleri.NegPosKokHalineGetir("NegPos.arff", "KokNegPos.arff");
		//VeriCek.hepsiburada("http://www.hepsiburada.com/lg-g3-d855-32gb-ithalatci-garantili-p-TELCEPLGG332-B-yorumlari?filtre=", "pos", "5");
		//VeriCek.hepsiburada("http://www.hepsiburada.com/xiaomi-mi-5-ithalatci-garantili-p-HBV0000000YQ1-yorumlari?filtre=", "pos", "5");
		//VeriCek.hepsiburada("http://www.hepsiburada.com/samsung-i8190-galaxy-s-iii-mini-p-TELCEPSAMI8190-M-yorumlari?filtre=", "pos","5", 15);
		//VeriCek.hepsiburada("http://www.hepsiburada.com/samsung-hm1500-bluetooth-kulaklik-cift-telefon-destegi-p-TELBKULSAMHM1500-yorumlari?filtre=","pos","5", 24);
		//VeriCek.hepsiburada("http://www.hepsiburada.com/xiaomi-mi-band-2-akilli-bileklik-siyah-p-TELAKLMIBAND2-yorumlari?filtre=","pos", "5", 19);
		//TestClass test = new TestClass();
		//test.CumleTestEt();

		//VeriCek.sikayetCom("teknosa");
		//VeriCek.sikayetCom("vatan-bilgisayar");
		
		VeriCek.sikayetComSoruIsaretiEkle("bimeks");
		
		//TestClass test = new TestClass();
		//test.CumleTestEt();
		
		//TestClass test = new TestClass();
		//test.NegPosTestEt("testlikNegPos.arff");
		
	}	
		
}
	